﻿$(document).ready(function () {
    $('.card').fadeIn(1000);
});
